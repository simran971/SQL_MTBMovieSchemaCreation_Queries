-- INSERTING SAMPLE DATA INTO TABLES -----------------------------------------------------------------------------------


-- 1. INSERTING DATA INTO BOOKING TABLE---------------------------------------------------------------------------------


INSERT INTO booking (booking_id, customer_id, movie_theatre_id, booking_date, no_of_seats)
VALUES
    (10001, 1, 101, '2023-12-19', 2),
    (10002, 2, 201, '2023-12-20', 3),
    (10003, 3, 301, '2023-12-21', 4),
    (10004, 4, 401, '2023-12-22', 1),
    (10005, 5, 501, '2023-12-23', 5),
    (10006, 6, 601, '2023-12-24', 2),
    (10007, 7, 701, '2023-12-25', 3),
    (10008, 8, 801, '2023-12-26', 4),
    (10009, 9, 901, '2023-12-27', 2),
    (10010, 10, 1001, '2023-12-28', 6);


-- 2. INSERTING DATA INTO CITY TABLE ------------------------------------------------------------------------------------------

INSERT INTO city (city_id, city_name)
VALUES
    (1, 'Mumbai'),
    (2, 'Delhi'),
    (3, 'Bangalore'),
    (4, 'Kolkata'),
    (5, 'Chennai'),
    (6, 'Hyderabad'),
    (7, 'Pune'),
    (8, 'Ahmedabad'),
    (9, 'Jaipur'),
    (10, 'Lucknow');


-- 3. INSERTING DATA INTO CUSTOMER TABLE ------------------------------------------------------------------------------------------

INSERT INTO customer (customer_id, first_name, last_name, username, password, date_of_birth, user_type_id, language_id)
VALUES
    (1, 'Simran', 'Soni', 'simrans', 'maveric123', '1997-05-02', 1, 1),
    (2, 'Akash', 'Raj', 'akashr', 'pass123', '1995-08-15', 2, 2),
    (3, 'Mohini', 'Singh', 'mohinis', 'abc@123', '1998-02-28', 3, 3),
    (4, 'Tanvi', 'Sharma', 'tanvis', 'tanvi@pass', '1994-11-30', 4, 4),
    (5, 'Divya', 'Patil', 'divyap', 'divya_pass', '1996-07-12', 5, 5),
    (6, 'Rishabh', 'Gupta', 'rishabhg', 'gupta123', '1993-03-27', 6, 6),
    (7, 'Neha', 'Rawat', 'nehar', 'rawat@123', '1991-08-18', 7, 7),
    (8, 'Rohit', 'Verma', 'rohitv', 'verma456', '1990-12-04', 8, 8),
    (9, 'Ananya', 'Singh', 'ananyas', 'singh789', '1996-06-09', 9, 9),
    (10, 'Aaryan', 'Kaur', 'aaryank', 'kaurpass', '1998-10-22', 10, 10),
    (11, 'Sanjay', 'Joshi', 'sanjayj', 'joshi@pass', '1992-04-15', 11, 1),
    (12, 'Shivani', 'Mishra', 'shivanim', 'mishra987', '1990-07-28', 12, 2),
    (13, 'Vikas', 'Kumar', 'vikask', 'kumar@123', '1997-01-09', 13, 3),
    (14, 'Poonam', 'Jha', 'poonamj', 'jha456', '1995-11-02', 14, 4),
    (15, 'Aditi', 'Goyal', 'aditig', 'goyal_pass', '1994-09-17', 15, 5),
    (16, 'Amitabh', 'Malhotra', 'amitabhm', 'malhotra1', '1996-02-20', 16, 6),
    (17, 'Tanushree', 'Patel', 'tanushreep', 'patelpass', '1993-06-05', 17, 7),
    (18, 'Mohammed', 'Khan', 'mohammedk', 'khanpass', '1991-03-10', 18, 8),
    (19, 'Anushka', 'Verma', 'anushkav', 'verma@123', '1998-12-25', 19, 9),
    (20, 'Siddharth', 'Rai', 'siddharthr', 'rai_pass', '1990-08-31', 20, 10);
    
    

-- 4. INSERTING DATA INTO LANGUAGE TABLE ------------------------------------------------------------------------------------------

INSERT INTO language (language_id, language_name)
VALUES
    (1, 'English'),
    (8, 'French'),
    (2, 'Hindi'),
    (5, 'Kannada'),
    (3, 'Korean'),
    (10, 'Malayalam'),
    (6, 'Marathi'),
    (7, 'Spanish'),
    (4, 'Tamil'),
    (9, 'Telugu');


-- 5. INSERTING DATA INTO MOVIE TABLE ------------------------------------------------------------------------------------------

INSERT INTO movie (movie_id, movie_name, movie_desc, release_date, duration, cover_photo_url, trailer_url, status_id)
VALUES
    (1, 'Interstellar', 'A team of astronauts travels through a wormhole in search of a new habitable planet to save humanity.', '2014-11-07', 169, 'https://cover-url.com/31', 'https://trailer-url.com/31', 4),
    (2, 'Inception', 'A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a CEO.', '2010-07-16', 148, 'https://cover-url.com/2', 'https://trailer-url.com/2', 2),
    (3, 'The Dark Knight', 'When the menace known as The Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice.', '2008-07-18', 152, 'https://cover-url.com/3', 'https://trailer-url.com/3', 1),
    (4, 'Pulp Fiction', 'The lives of two mob hitmen, a boxer, a gangster and his wife, and a pair of diner bandits intertwine in four tales of violence and redemption.', '1994-10-14', 154, 'https://cover-url.com/4', 'https://trailer-url.com/4', 1),
    (5, 'Forrest Gump', 'The life journey of a man with low IQ, witnessing and influencing historical events in the 20th century United States.', '1994-07-06', 142, 'https://cover-url.com/5', 'https://trailer-url.com/5', 3),
    (6, 'Fight Club', 'An insomniac office worker and a devil-may-care soapmaker form an underground fight club that evolves into much more.', '1999-10-15', 139, 'https://cover-url.com/6', 'https://trailer-url.com/6', 5),
    (7, 'The Lord of the Rings: The Fellowship of the Ring', 'A meek Hobbit from the Shire and eight companions set out on a journey to destroy the powerful One Ring and save Middle-earth from the Dark Lord Sauron.', '2001-12-19', 178, 'https://cover-url.com/7', 'https://trailer-url.com/7', 1),
    (8, 'La La Land', 'A jazz musician and an aspiring actress meet and fall in love while pursuing their dreams in Los Angeles.', '2016-12-09', 128, 'https://cover-url.com/8', 'https://trailer-url.com/8', 6),
    (9, 'Dilwale Dulhania Le Jayenge', 'A young man and woman fall in love during a trip but face opposition from their families.', '1995-10-20', 190, 'https://cover-url.com/9', 'https://trailer-url.com/9', 6),
    (10, 'Zindagi Na Milegi Dobara', 'Three friends rediscover life\'s joys and challenges while on a road trip.', '2011-07-15', 155, 'https://cover-url.com/10', 'https://trailer-url.com/10', 8),
    (11, 'Sairat', 'A love story of a low-caste boy and a wealthy girl, facing societal pressures and challenges.', '2016-04-29', 174, 'https://cover-url.com/11', 'https://trailer-url.com/11', 1),
    (12, 'Andhadhun', 'A blind pianist gets embroiled in the murder of a former film actor.', '2018-10-05', 139, 'https://cover-url.com/12', 'https://trailer-url.com/12', 8),
    (13, 'Kaaka Muttai', 'Two young brothers desire to taste pizza and go to great lengths to afford it.', '2015-06-05', 109, 'https://cover-url.com/13', 'https://trailer-url.com/13', 8),
    (14, '96', 'Two high school sweethearts meet again after many years, stirring up old emotions.', '2018-10-04', 158, 'https://cover-url.com/14', 'https://trailer-url.com/14', 7),
    (15, 'Amélie', 'A quirky young woman changes the lives of those around her as she sets out to improve her own.', '2001-04-25', 122, 'https://cover-url.com/15', 'https://trailer-url.com/15', 1),
    (16, 'The Grand Budapest Hotel', 'The adventures of a legendary concierge and a lobby boy at a famous European hotel.', '2014-03-28', 99, 'https://cover-url.com/16', 'https://trailer-url.com/16', 1),
    (17, 'Gully Boy', 'A street rapper rises from the slums of Mumbai to become a shining star.', '2019-02-14', 153, 'https://cover-url.com/17', 'https://trailer-url.com/17', 2),
    (18, 'The Intouchables', 'The bond between a wealthy quadriplegic man and his caretaker, a young offender from the suburbs.', '2011-11-02', 112, 'https://cover-url.com/18', 'https://trailer-url.com/18', 2),
    (19, 'Aruvi', 'The journey of a young woman who faces societal issues with resilience and determination.', '2016-12-15', 130, 'https://cover-url.com/19', 'https://trailer-url.com/19', 2),
    (20, 'Queen', 'A young woman embarks on a solo honeymoon trip after her marriage falls apart.', '2013-03-07', 146, 'https://cover-url.com/20', 'https://trailer-url.com/20', 1);



-- 6. INSERTING DATA INTO MOVIE_THEATRE TABLE ------------------------------------------------------------------------------------------


INSERT INTO movie_theatre (movie_theatre_id, movie_id, theatre_id)
VALUES
    (101, 1, 1),
    (201, 2, 5),
    (301, 3, 8),
    (401, 4, 2),
    (501, 5, 7),
    (601, 6, 4),
    (701, 7, 6),
    (801, 8, 9),
    (901, 9, 3),
    (1001, 10, 10);


-- 7. INSERTING DATA INTO MOVIE_THEATRE TABLE ------------------------------------------------------------------------------------------

INSERT INTO status (status_id, status_name)
VALUES
    (1, 'Released'),
    (2, 'In Progress'),
    (3, 'Postponed'),
    (4, 'Cancelled'),
	(5, 'Premiering'),
	(6, 'Completed'),
	(7, 'On Hold'),
	(8, 'Not Started');
    
 
-- 8. INSERTING DATA INTO THEATRE TABLE ------------------------------------------------------------------------------------------

INSERT INTO theatre (theatre_id, theatre_name, city_id, ticket_price)
VALUES
    (1, 'Mumbai Cinema', 1, 150.00),
    (2, 'Delhi Theatre', 2, 150.00),
    (3, 'Bangalore Hall', 3, 150.00),
    (4, 'Kolkata Plaza', 4, 150.00),
    (5, 'Chennai Cineplex', 5, 150.00),
    (6, 'Hyderabad Movies', 6, 150.00),
    (7, 'Pune Multiplex', 7, 150.00),
    (8, 'Pune Imax', 7, 150.00),
    (9, 'Directors Cut', 3, 150.00),
    (10, 'Namma Cinema', 3, 150.00);


-- 9. INSERTING DATA INTO USER_TYPE TABLE ------------------------------------------------------------------------------------------

INSERT INTO user_type (user_type_id, user_type_name)
VALUES
    (1, 'simransoni'),
    (2, 'akashraj'),
    (3, 'mohinisingh'),
    (4, 'tanvisharma'),
    (5, 'divyapatil'),
    (6, 'rishabhgupta'),
    (7, 'neharawat'),
    (8, 'rohitverma'),
    (9, 'ananyasingh'),
    (10, 'aaryankaur'),
    (11, 'sanjayjoshi'),
    (12, 'shivanimishra'),
    (13, 'vikaskumar'),
    (14, 'poonamjha'),
    (15, 'aditigoyal'),
    (16, 'amitabhmalhotra'),
    (17, 'tanushreepatel'),
    (18, 'mohammedkhan'),
    (19, 'anushkaverma'),
    (20, 'siddharthrai');


-- ----------------------------------------------------------------------------------------------------------------------------




