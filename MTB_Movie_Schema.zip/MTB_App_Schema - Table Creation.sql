-- ASSIGNMENT SYNTAX-----------------------------------------------------


-- CREATING DATABASE --------------------------------------------------------------------------------------
CREATE DATABASE MTBApp_movies_schema;
use MTBApp_movies_schema;


-- CREATING CUSTOMER TABLE -------------------------------------------------------------------------------


create table customer ( 
customer_id INT(10) PRIMARY KEY, 
first_name VARCHAR(20) NOT NULL,
last_name VARCHAR(20),
username VARCHAR(20) NOT NULL UNIQUE,
password VARCHAR(20) NOT NULL, CHECK(LENGTH(password) > 5),
date_of_birth DATE NOT NULL,
user_type_id INT(10) NOT NULL, FOREIGN KEY (user_type_id) REFERENCES User_type
(User_type_id),
language_id INT(10) NOT NULL, 
	FOREIGN KEY (language_id) REFERENCES language(language_id)
    );


-- CREATING USER_NAME TABLE --------------------------------------------------------------------------------------------
create table user_type ( 
user_type_id INT(10) PRIMARY KEY,
user_type_name VARCHAR(20) UNIQUE DEFAULT "Customer"
);


-- CREATING LANGUAGE TABLE ---------------------------------------------------------------------------------------------
create table language ( 
language_id INT(10) PRIMARY KEY,
language_name VARCHAR(20) NOT NULL UNIQUE
);


-- CREATING MOVIE TABLE --------------------------------------------------------------------------------------------------
create table movie ( 
movie_id INT(10) PRIMARY KEY,
movie_name VARCHAR(50) NOT NULL UNIQUE,
movie_desc VARCHAR(500) NOT NULL,
release_date DATE NOT NULL,
duration INT(3) NOT NULL , CHECK(duration>60),
cover_photo_url VARCHAR(500) NOT NULL,
trailer_url VARCHAR(500) NOT NULL,
status_id INT(10) NOT NULL, FOREIGN KEY (status_id) REFERENCES status(status_id)
);


-- CREATING STATUS TABLE ---------------------------------------------------------------------------------------------
create table status (
status_id INT(10) PRIMARY KEY,
status_name VARCHAR(20) NOT NULL UNIQUE);


-- CREATING THEATRE TABLE -----------------------------------------------------------------------------------------------
create table theatre (
theatre_id INT(10) PRIMARY KEY,
theatre_name VARCHAR(20) NOT NULL UNIQUE,
city_id INT(10) NOT NULL, FOREIGN KEY(city_id) REFERENCES city(city_id),
ticket_price FLOAT(5,2) NOT NULL DEFAULT 150.00
);



-- CREATING CITY TABLE -----------------------------------------------------------------------------------------------------
create table city ( 
city_id INT(10) PRIMARY KEY,
city_name VARCHAR(20) NOT NULL);



-- movie_theatre -----------------------------------------------------------------------------------------------------------


create table movie_theatre (
movie_theatre_id INT(10) PRIMARY KEY,
movie_id INT(10), FOREIGN KEY(movie_id) REFERENCES movie (movie_id),
theatre_id INT(10), FOREIGN KEY(theatre_id) REFERENCES theatre (theatre_id)
);


-- CREATING BOOKING TABLE ---------------------------------------------------------------------------------------------------


create table booking_id (
booking_id INT(10) PRIMARY KEY,
customer_id INT(10) NOT NULL, 
FOREIGN KEY (customer_id) REFERENCES customer(customer_id),
movie_theatre_id INT(10) NOT NULL,
FOREIGN KEY (movie_theatre_id) REFERENCES movie_theatre(movie_theatre_id),
booking_date DATE NOT NULL,
no_of_seats INT(10) NOT NULL
);

