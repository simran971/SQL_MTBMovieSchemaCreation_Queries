-- 5 VIEWS ------------------------------------------------------------------------------------------------------------------

-- 1. Which view shows the complete list of movies along with their theatre and city details where they are being screened?
SELECT *
FROM Movie_Theatre_City_View;


-- 2. How can we obtain the booking details with customer names for reference?
SELECT *
FROM Booking_Customer_Details_View;

-- 3. Which view exhibits movies released before the year 2000?
SELECT *
FROM Movies_Released_Before_2000_View;

-- 4. Where can we find a list of customers with their user types?
SELECT *
FROM User_Type_Customer_View;

-- 5. Which view provides details of movies playing in cities like Delhi, Mumbai, and Bangalore?
SELECT *
FROM Movies_In_Specific_Cities_View;

