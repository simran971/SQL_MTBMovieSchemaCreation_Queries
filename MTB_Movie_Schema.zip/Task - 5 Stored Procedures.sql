-- 5 Stored procedures-----------------------------------------------------------------------------------------------------


-- 1. STORED PROCEDURE TO INSERT VALUES IN USER_TYPE TABLE >>>>>>>>>>>>>>>>>>>>>
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_insert_usertype`( 
    IN sp_user_type_id INT(10), 
    IN sp_user_type_name VARCHAR(20)
)
BEGIN
    INSERT INTO user_type (
        user_type_id,
        user_type_name
    )
    VALUES (
        sp_user_type_id,
        sp_user_type_name
    );
END //
DELIMITER ;


-- 2. STORED PROCEDURE TO INSERT VALUES IN LANGUAGE TABLE >>>>>>>>>>>>>>>>>>>>>

DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_insert_language`( 
    IN sp_language_id INT(10),  
    IN sp_language_name VARCHAR(20)
)
BEGIN
    INSERT INTO language (
        language_id,
        language_name
    )
    VALUES (
        sp_language_id,
        sp_language_name
    );
END //
DELIMITER ;


-- 3. STORED PROCEDURE TO INSERT VALUES IN STATUS TABLE >>>>>>>>>>>>>>>>>>>>>
DELIMITER //
CREATE PROCEDURE `sp_insert_status`(
    IN sp_status_id INT,
    IN sp_status_name VARCHAR(50)
)
BEGIN
    INSERT INTO status (status_id, status_name)
    VALUES (sp_status_id, sp_status_name);
END //
DELIMITER ;


-- 4. STORED PROCEDURE TO INSERT VALUES IN MOVIE TABLE >>>>>>>>>>>>>>>>>>>>>
DELIMITER //
CREATE PROCEDURE `sp_insert_movie`(
    IN sp_movie_id INT,
    IN sp_movie_name VARCHAR(50),
    IN sp_movie_desc VARCHAR(500),
    IN sp_release_date DATE,
    IN sp_duration INT,
    IN sp_cover_photo_url VARCHAR(500),
    IN sp_trailer_url VARCHAR(500),
    IN sp_status_id INT
)
BEGIN
    INSERT INTO movie (movie_id, movie_name, movie_desc, release_date, duration, cover_photo_url, trailer_url, status_id)
    VALUES (sp_movie_id, sp_movie_name, sp_movie_desc, sp_release_date, sp_duration, sp_cover_photo_url, sp_trailer_url, sp_status_id);
END //
DELIMITER ;


-- 5. STORED PROCEDURE TO INSERT VALUES IN CITY TABLE >>>>>>>>>>>>>>>>>>>>>
DELIMITER //
CREATE PROCEDURE `sp_insert_city`(
    IN sp_city_id INT,
    IN sp_city_name VARCHAR(20)
)
BEGIN
    INSERT INTO city (city_id, city_name)
    VALUES (sp_city_id, sp_city_name);
END //
DELIMITER ;

-- -----------------------------------------------------------------------------------------------------------------------