STORED PROCEDURE 











-- CREATING STORED PROCEDURES TO INSERT VALUES IN user_type table, language table, customer table


-- STORED PROCEDURE TO INSERT VALUES IN USER_TYPE TABLE >>>>>>>>>>>>>>>>>>>>>


DELIMITER //


CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_insert_usertype`( 
    IN sp_user_type_id INT(10), 
    IN sp_user_type_name VARCHAR(20)
)
BEGIN
    INSERT INTO user_type (
        user_type_id,
        user_type_name
    )
    VALUES (
        sp_user_type_id,
        sp_user_type_name
    );
END //


DELIMITER ;


-- STORED PROCEDURE TO INSERT VALUES IN LANGUAGE TABLE >>>>>>>>>>>>>>>>>>>>>


DELIMITER //


CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_insert_language`( 
    IN sp_language_id INT(10),  
    IN sp_language_name VARCHAR(20)
)
BEGIN
    INSERT INTO language (
        language_id,
        language_name
    )
    VALUES (
        sp_language_id,
        sp_language_name
    );
END //


DELIMITER ;


-- STORED PROCEDURE TO INSERT VALUES IN CUSTOMER TABLE >>>>>>>>>>>>>>>>>>>>>


DELIMITER //


CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_insertcustomer`( 
    IN sp_customer_id INT(10), 
    IN sp_first_name VARCHAR(20),
    IN sp_last_name VARCHAR(20),
    IN sp_username VARCHAR(20),
    IN sp_password VARCHAR(20),
    IN sp_date_of_birth DATE,
    IN sp_user_type_id INT(10),
    IN sp_language_id INT(10)
)
BEGIN
    INSERT INTO customer (
        customer_id, 
        first_name,
        last_name,
        username,
        password,
        date_of_birth,
        user_type_id,
        language_id
    )
    VALUES (
        sp_customer_id,
        sp_first_name,
        sp_last_name,
        sp_username,
        sp_password,
        sp_date_of_birth,
        sp_user_type_id,
        sp_language_id
    );
END //


DELIMITER ;



-- STORED PROCEDURE TO INSERT VALUES IN STATUS TABLE >>>>>>>>>>>>>>>>>>>>>


DELIMITER //


CREATE PROCEDURE `sp_insert_status`(
    IN sp_status_id INT,
    IN sp_status_name VARCHAR(50)
)
BEGIN
    INSERT INTO status (status_id, status_name)
    VALUES (sp_status_id, sp_status_name);
END //


DELIMITER ;



-- -- STORED PROCEDURE TO INSERT VALUES IN MOVIE TABLE >>>>>>>>>>>>>>>>>>>>>


DELIMITER //


CREATE PROCEDURE `sp_insert_movie`(
    IN sp_movie_id INT,
    IN sp_movie_name VARCHAR(50),
    IN sp_movie_desc VARCHAR(500),
    IN sp_release_date DATE,
    IN sp_duration INT,
    IN sp_cover_photo_url VARCHAR(500),
    IN sp_trailer_url VARCHAR(500),
    IN sp_status_id INT
)
BEGIN
    INSERT INTO movie (movie_id, movie_name, movie_desc, release_date, duration, cover_photo_url, trailer_url, status_id)
    VALUES (sp_movie_id, sp_movie_name, sp_movie_desc, sp_release_date, sp_duration, sp_cover_photo_url, sp_trailer_url, sp_status_id);
END //


DELIMITER ;


-- -- -- STORED PROCEDURE TO INSERT VALUES IN CITY TABLE >>>>>>>>>>>>>>>>>>>>>


DELIMITER //


CREATE PROCEDURE `sp_insert_city`(
    IN sp_city_id INT,
    IN sp_city_name VARCHAR(20)
)
BEGIN
    INSERT INTO city (city_id, city_name)
    VALUES (sp_city_id, sp_city_name);
END //


DELIMITER ;



-- -- -- STORED PROCEDURE TO INSERT VALUES IN THEATRE TABLE >>>>>>>>>>>>>>>>>>>>>


DELIMITER //


CREATE PROCEDURE `sp_insert_theatre`(
    IN sp_theatre_id INT,
    IN sp_theatre_name VARCHAR(20),
    IN sp_city_id INT,
    IN sp_ticket_price DECIMAL(5,2)
)
BEGIN
    INSERT INTO theatre (theatre_id, theatre_name, city_id, ticket_price)
    VALUES (sp_theatre_id, sp_theatre_name, sp_city_id, sp_ticket_price);
END //


DELIMITER ;


-- -- -- STORED PROCEDURE TO INSERT VALUES IN MOVIE_THEATRE TABLE >>>>>>>>>>>>>>>>>>>>>


DELIMITER //


CREATE PROCEDURE `sp_insert_movie_theatre`(
    IN sp_movie_theatre_id INT,
    IN sp_movie_id INT,
    IN sp_theatre_id INT
)
BEGIN
    INSERT INTO movie_theatre (movie_theatre_id, movie_id, theatre_id)
    VALUES (sp_movie_theatre_id, sp_movie_id, sp_theatre_id);
END //


DELIMITER ;



-- -- -- STORED PROCEDURE TO INSERT VALUES IN BOOKING TABLE >>>>>>>>>>>>>>>>>>>>>


DELIMITER //


CREATE PROCEDURE `sp_insert_booking`(
    IN sp_booking_id INT,
    IN sp_customer_id INT,
    IN sp_movie_theatre_id INT,
    IN sp_booking_date DATE,
    IN sp_no_of_seats INT
)
BEGIN
    INSERT INTO booking (booking_id, customer_id, movie_theatre_id, booking_date, no_of_seats)
    VALUES (sp_booking_id, sp_customer_id, sp_movie_theatre_id, sp_booking_date, sp_no_of_seats);
END //


DELIMITER ;