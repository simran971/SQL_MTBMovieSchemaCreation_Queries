-- 5 Join Queries------------------------------------------------------------------------------------------

-- 1. Who are the customers and their corresponding booked movies?
SELECT c.first_name, c.last_name, m.movie_name
FROM customer c
INNER JOIN booking_id b ON c.customer_id = b.customer_id
INNER JOIN movie_theatre mt ON b.movie_theatre_id = mt.movie_theatre_id
INNER JOIN movie m ON mt.movie_id = m.movie_id;

-- 2. Which movies are being shown in Chennai along with their corresponding theatre details?
SELECT m.movie_name, t.theatre_name
FROM movie m
INNER JOIN movie_theatre mt ON m.movie_id = mt.movie_id
INNER JOIN theatre t ON mt.theatre_id = t.theatre_id
INNER JOIN city c ON t.city_id = c.city_id
WHERE c.city_name = 'Chennai';

-- 3. What are the bookings made by Neha Rawat and the associated movie details?
SELECT b.booking_id, m.movie_name, b.booking_date
FROM booking_id b
INNER JOIN customer c ON b.customer_id = c.customer_id
INNER JOIN movie_theatre mt ON b.movie_theatre_id = mt.movie_theatre_id
INNER JOIN movie m ON mt.movie_id = m.movie_id
WHERE c.first_name = 'Neha' AND c.last_name = 'Rawat';

-- 4. Which customers have booked movies playing in Mumbai?
SELECT DISTINCT c.first_name, c.last_name
FROM customer c
INNER JOIN booking_id b ON c.customer_id = b.customer_id
INNER JOIN movie_theatre mt ON b.movie_theatre_id = mt.movie_theatre_id
INNER JOIN theatre t ON mt.theatre_id = t.theatre_id
INNER JOIN city ci ON t.city_id = ci.city_id
WHERE ci.city_name = 'Mumbai';

-- 5. What are the movies and their respective cities where bookings are scheduled for December 24, 2023?
SELECT m.movie_name, ci.city_name
FROM movie m
INNER JOIN movie_theatre mt ON m.movie_id = mt.movie_id
INNER JOIN theatre t ON mt.theatre_id = t.theatre_id
INNER JOIN city ci ON t.city_id = ci.city_id
INNER JOIN booking_id b ON mt.movie_theatre_id = b.movie_theatre_id
WHERE b.booking_date = '2023-12-24';

