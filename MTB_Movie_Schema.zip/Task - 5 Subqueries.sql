-- 5 Sub Queries ------------------------------------------------------------------------------------------------------

-- 1. What are the details of bookings made by customers with the user type 'Customer'?
SELECT *
FROM booking_id
WHERE customer_id IN (SELECT customer_id FROM customer WHERE user_type_id = (SELECT user_type_id FROM user_type WHERE user_type_name = 'Customer'));

-- 2. Which movies have durations longer than the average duration of all movies?
SELECT *
FROM movie
WHERE duration > (SELECT AVG(duration) FROM movie);

-- 3.  How many customers have booked tickets for movies playing in Delhi and Hyderabad?
SELECT COUNT(DISTINCT c.customer_id) as no_of_customers
FROM customer c
WHERE c.customer_id IN (SELECT DISTINCT b.customer_id
                        FROM booking_id b
                        INNER JOIN movie_theatre mt ON b.movie_theatre_id = mt.movie_theatre_id
                        INNER JOIN theatre t ON mt.theatre_id = t.theatre_id
                        INNER JOIN city ci ON t.city_id = ci.city_id
                        WHERE ci.city_name IN ('Delhi', 'Hyderabad'));


-- 4. What are the movies released before the release date of the movie 'Inception'?
SELECT *
FROM movie
WHERE release_date < (SELECT release_date FROM movie WHERE movie_name = 'Inception');

-- 5. How many bookings were made for movies in theatres with ticket prices higher than the average ticket price of all theatres?
SELECT COUNT(*)
FROM booking_id
WHERE movie_theatre_id IN (SELECT mt.movie_theatre_id
                           FROM movie_theatre mt
                           INNER JOIN theatre t ON mt.theatre_id = t.theatre_id
                           WHERE t.ticket_price > (SELECT AVG(ticket_price) FROM theatre));
